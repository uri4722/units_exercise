function NoPage() {
    return <>
        <h1>404</h1>
        <p>sorry the page not found</p>
    </>
}
export default NoPage;